<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LumaDesk</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>
<body>
    <header>
        <nav class="navbar">
            <a href="/" class="logo">LumaDesk</a>
            <a href="#contact" class="nav-button">Get Started</a>
        </nav>
    </header>

    <main>
        <section class="hero">
            <div>
                <p class="eyebrow">Modern Business Solutions</p>
                <h1>Work smarter with LumaDesk.</h1>
                <p class="hero-text">
                    A clean, modern business landing page built with Laravel,
                    Blade, HTML, CSS, and JavaScript.
                </p>
                <a href="#contact" class="cta-button">Explore LumaDesk</a>
            </div>
        </section>

        <section class="features">
            <article>
                <h2>Simple</h2>
                <p>Clean interfaces designed to be easy to understand and use.</p>
            </article>
            <article>
                <h2>Responsive</h2>
                <p>A layout that adapts smoothly to desktops, tablets, and phones.</p>
            </article>
            <article>
                <h2>Interactive</h2>
                <p>Subtle animations and JavaScript interactions improve the experience.</p>
            </article>
        </section>

        <section id="contact" class="contact">
            <h2>Ready to get started?</h2>
            <button id="contactButton" type="button">Contact LumaDesk</button>
        </section>
    </main>

    <footer>
        <p>&copy; {{ date('Y') }} LumaDesk. All rights reserved.</p>
    </footer>

    <script src="{{ asset('js/script.js') }}"></script>
</body>
</html>
