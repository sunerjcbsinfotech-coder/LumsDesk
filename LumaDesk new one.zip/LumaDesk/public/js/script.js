document.addEventListener("DOMContentLoaded", () => {
    const contactButton = document.getElementById("contactButton");

    if (contactButton) {
        contactButton.addEventListener("click", () => {
            alert("Thank you for your interest in LumaDesk!");
        });
    }
});
