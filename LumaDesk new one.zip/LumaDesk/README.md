# LumaDesk

A responsive business landing page created for a Laravel web development class activity.

## Technologies

- Laravel
- Blade
- HTML5
- CSS3
- JavaScript
- Responsive Design
- CSS Animations and Transitions

## Project Goal

LumaDesk is a static front-end business landing page demonstrating clean UI design,
responsive layouts, CSS animation/transition techniques, and basic JavaScript interaction.

## Laravel Structure

The project follows Laravel's standard folder conventions, including:

- `resources/views/landing.blade.php` for the Blade view
- `routes/web.php` for the landing page route
- `public/css/` for styles
- `public/js/` for JavaScript
- `public/images/` for image assets

## Running the Project

If this is placed inside a Laravel installation:

```bash
php artisan serve
```

Then open:

http://127.0.0.1:8000
